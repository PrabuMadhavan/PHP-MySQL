<?php 
include 'config.php';
mysqli_select_db($conn,$db_name);
$sql = "DELETE FROM users WHERE id = 1";
$query = mysqli_query($conn,$sql);
if(!$query)
{
    echo "Query does not work.".mysqli_error($conn);die;
}
else
{
    echo "Data successfully delete.";
}
?>