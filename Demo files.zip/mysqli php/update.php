<?php 
include 'config.php';
mysqli_select_db($conn, $db_name);
$sql = "UPDATE users SET firstname = 'OM_new',lastname = 'Dayal_new',email = 'om@new.com' WHERE id=1 ";
$query = mysqli_query($conn,$sql);
if(!$query)
{
    echo "Query does not work.".mysqli_error($conn);die;
}
else
{
    echo "Data successfully updated";
}
?>