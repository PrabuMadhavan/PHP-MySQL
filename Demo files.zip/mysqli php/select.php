<?php 
include 'config.php';
mysqli_select_db($conn,$db_name);
$sql = "SELECT * FROM users";
$query = mysqli_query($conn,$sql);
if(!$query)
{
    echo "Query does not work.".mysqli_error($conn);die;
}
while($data = mysqli_fetch_array($query))
{
    echo "Id = ".$data['id']."<br>";
    echo "Firstname = ".$data['firstname']."<br>";
    echo "Lastname = ".$data['lastname']."<br>";
    echo "Email = ".$data['email']."<br><hr>";
}
?>