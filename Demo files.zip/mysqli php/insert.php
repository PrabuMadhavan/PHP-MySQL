<?php 
include 'config.php';	//Database configuration file
mysqli_select_db($conn, $db_name);
$sql = "INSERT INTO users (id, firstname, lastname, email) VALUES (NULL,'Om','Dayal','Om@xmail.com')";
$query = mysqli_query($conn, $sql);
if (!$query) {
    echo "User does not inserted. Error : " . mysqli_error($conn);
} else {
    echo "User inserted successfully.";
}
?>